public class numinvertido {
    public static int invertirnum (int numero) {
        if (numero < 10) {
            return numero;
        }
        int ultimonumero = numero % 10;
        int longitud = (int) Math.log10(numero);
        return ultimonumero * (int) Math.pow(10, longitud) + invertirnum (numero / 10);// esta es la funcion para invertir un numero
    }
    public static boolean letra (String input) {
        if (input == null || input.isEmpty()) {
            return false;
        }
        for (int i = 0; i < input.length(); i++) {
            if (!Character.isDigit(input.charAt(i))) {// esta es la funcion para validar que el numero ingresado sea un numero entero
                return false;
            }
        }
        return true;
    }
}
