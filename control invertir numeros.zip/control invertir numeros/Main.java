import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingresa un número entero: ");
        String input = scanner.nextLine();
        if (!numinvertido.letra(input)) {
            System.out.println("Error: Debes ingresar un número entero.");// esto es para validar que el caracter ingresado sea un numero
            return;
        }
        int numero = Integer.parseInt(input);
        int numeroInvertido = numinvertido.invertirnum(numero);
        System.out.println("Número invertido: " + numeroInvertido);
    }
}
